from django import forms
from .models import Transaction, Transfer, Account

class TransactionForm(forms.ModelForm):
    class Meta:
        model = Transaction
        fields = [
            'account',
            'date',
            'subcategory',
            'description',
            'debit',
            'credit',
            'cleared',
            'write_off',
            
        ]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['account'].queryset = Account.objects.filter(active=True)
        # Optional: Add filtering or logging by transaction_type if needed later

    def clean(self):
        cleaned_data = super().clean()
        debit = cleaned_data.get("debit") or 0
        credit = cleaned_data.get("credit") or 0
        cleaned_data["amount"] = credit - debit
        return cleaned_data

    def save(self, commit=True):
        instance = super().save(commit=False)
        instance.amount = (instance.credit or 0) - (instance.debit or 0)
        if commit:
            instance.save()
        return instance

class TransferForm(forms.ModelForm):
    class Meta:
        model = Transfer
        fields = [
            'from_account', 
            'to_account', 
            'amount', 
            'date', 
            'description'
            ]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['from_account'].queryset = Account.objects.filter(active=True)
        self.fields['to_account'].queryset = Account.objects.filter(active=True)

    def save(self, commit=True):
        transfer = super().save(commit=commit)
        return transfer


class infer_transaction_type(Account):
    def infer_transaction_type(self):
        if self.account.account_type == 'LOAN':
            return 'LOAN_PAYMENT'
        elif self.account.account_type == 'CHARGE':
            return 'CC_PAYMENT'
        else:
            return 'UNKNOWN'
